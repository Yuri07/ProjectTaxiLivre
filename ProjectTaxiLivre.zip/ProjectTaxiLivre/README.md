# ProjectTaxiLivre
Projeto de App de transporte.

Modelos de arquitetura e padrões: MVP, Clean Architecture.

Bibliotecas utilizadas:butterknife, dagger, glide, googledirectionlibrary, firebase-database, firebase-auth, firebase-storage, firebase-messaging, android.gms.

App Cliente:

![alt tag](https://firebasestorage.googleapis.com/v0/b/projecttaxilivre-1515301730986.appspot.com/o/urlsgithub%2FTaxiLivre1r.png?alt=media&token=cdeef17b-b388-40f5-a256-956f20c140c5 "Map")      ![alt tag](https://firebasestorage.googleapis.com/v0/b/projecttaxilivre-1515301730986.appspot.com/o/urlsgithub%2Ftaxilivre%2Ftaxilivresolicitar.png?alt=media&token=36e58334-beb4-4fd5-920b-0083d8ff19ec "solicitar")   ![alt tag](https://firebasestorage.googleapis.com/v0/b/projecttaxilivre-1515301730986.appspot.com/o/urlsgithub%2Ftaxilivre%2FProjectTaxiLivreTravelRequestresized.jpg?alt=media&token=6123608f-0960-4487-844c-f684cd58f485 "travelrequested")

App Motorista:

![alt tag](https://firebasestorage.googleapis.com/v0/b/projecttaxilivre-1515301730986.appspot.com/o/urlsgithub%2Ftaxilivre%2Ftaxilivredriverhome.png?alt=media&token=02da8604-9a32-4f99-9a6e-c5abbb3283fb "home")

Telas gerais

![alt tag](https://firebasestorage.googleapis.com/v0/b/projecttaxilivre-1515301730986.appspot.com/o/urlsgithub%2Ftaxilivre%2FProjectTaxiLivreNotificationMsgresized.jpg?alt=media&token=38c63d2c-2e6b-49fd-b08c-f56c21c45d5c "Notification")   ![alt tag](https://firebasestorage.googleapis.com/v0/b/projecttaxilivre-1515301730986.appspot.com/o/urlsgithub%2Ftaxilivre%2FProjectTaxiLivreChatresized.jpg?alt=media&token=ea7a9d54-9d5b-4873-8459-e1a3c024637b "Chat")

![alt tag](https://firebasestorage.googleapis.com/v0/b/projecttaxilivre-1515301730986.appspot.com/o/urlsgithub%2Ftaxilivre%2Ftaxilivredriveravaliation.png?alt=media&token=9734840d-fc34-4c3d-aa84-6b1d70086b58 "avaliation")   ![alt tag](https://firebasestorage.googleapis.com/v0/b/projecttaxilivre-1515301730986.appspot.com/o/urlsgithub%2Ftaxilivre%2Ftaxilivredriverconta1.png?alt=media&token=fc4d472f-3cab-4abe-971e-b1b8445b76f3 "conta1")   ![alt tag](https://firebasestorage.googleapis.com/v0/b/projecttaxilivre-1515301730986.appspot.com/o/urlsgithub%2Ftaxilivre%2Ftaxilivredriverconta2.png?alt=media&token=9a560411-4311-41fc-b5a7-56e1fd66bf37 "conta2")

![alt tag](https://firebasestorage.googleapis.com/v0/b/projecttaxilivre-1515301730986.appspot.com/o/urlsgithub%2FTaxiLivre2r.png?alt=media&token=f32e0ebc-e5ca-4797-ba3d-a12dfa73a001 "DrawNavigation")
