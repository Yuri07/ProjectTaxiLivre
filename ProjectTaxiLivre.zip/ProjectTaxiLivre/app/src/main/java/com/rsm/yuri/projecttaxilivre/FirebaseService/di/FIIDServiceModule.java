package com.rsm.yuri.projecttaxilivre.FirebaseService.di;

import dagger.Module;

/**
 * Created by yuri_ on 25/04/2018.
 */
@Module
public class FIIDServiceModule {
}
