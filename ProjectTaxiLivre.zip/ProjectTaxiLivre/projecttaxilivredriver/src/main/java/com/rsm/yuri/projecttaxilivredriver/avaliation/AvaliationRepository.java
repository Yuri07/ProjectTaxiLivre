package com.rsm.yuri.projecttaxilivredriver.avaliation;

/**
 * Created by yuri_ on 07/03/2018.
 */

public interface AvaliationRepository {
    void retrieveRatings(String email);
}
