package com.rsm.yuri.projecttaxilivre.adddialog;

/**
 * Created by yuri_ on 10/11/2017.
 */

public interface AddDialogInteractor {
    void add(String key, String value);
}
