package com.rsm.yuri.projecttaxilivredriver.historictravel;

public interface HistoricTravelPresenter {
}
