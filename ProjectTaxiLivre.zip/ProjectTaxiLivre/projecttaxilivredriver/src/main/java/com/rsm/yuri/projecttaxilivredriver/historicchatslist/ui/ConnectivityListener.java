package com.rsm.yuri.projecttaxilivredriver.historicchatslist.ui;

public interface ConnectivityListener {

    boolean getConnectivityStatus();

}
