package com.rsm.yuri.projecttaxilivredriver.FirebaseService.di;

import dagger.Module;

/**
 * Created by yuri_ on 25/04/2018.
 */
@Module
public class FIIDServiceModule {
}
