package com.rsm.yuri.projecttaxilivre.historicchatslist;

/**
 * Created by yuri_ on 15/01/2018.
 */

public interface HistoricChatsListSessionInteractor {
    void changeConnectionStatus(int status);
}
