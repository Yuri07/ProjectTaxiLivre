package com.rsm.yuri.projecttaxilivre.travelslist;

/**
 * Created by yuri_ on 29/01/2018.
 */

public interface TravelListPresenter {
}
