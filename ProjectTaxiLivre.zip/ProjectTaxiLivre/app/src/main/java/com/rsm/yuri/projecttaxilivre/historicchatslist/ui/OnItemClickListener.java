package com.rsm.yuri.projecttaxilivre.historicchatslist.ui;

import com.rsm.yuri.projecttaxilivre.map.entities.Driver;

/**
 * Created by yuri_ on 13/01/2018.
 */

public interface OnItemClickListener {

    void onItemClick(Driver driver);
    void onItemLongClick(Driver driver);
    //boolean getConnectivityStatus();
}
