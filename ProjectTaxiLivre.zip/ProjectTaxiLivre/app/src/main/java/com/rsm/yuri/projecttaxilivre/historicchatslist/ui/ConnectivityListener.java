package com.rsm.yuri.projecttaxilivre.historicchatslist.ui;

public interface ConnectivityListener {

    boolean getConnectivityStatus();

}
