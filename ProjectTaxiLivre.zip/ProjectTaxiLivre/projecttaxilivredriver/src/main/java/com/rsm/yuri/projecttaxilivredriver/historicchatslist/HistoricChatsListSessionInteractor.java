package com.rsm.yuri.projecttaxilivredriver.historicchatslist;

/**
 * Created by yuri_ on 15/01/2018.
 */

public interface HistoricChatsListSessionInteractor {
    void changeConnectionStatus(int status);
}
