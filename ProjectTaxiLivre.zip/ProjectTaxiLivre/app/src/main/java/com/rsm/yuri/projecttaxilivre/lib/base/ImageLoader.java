package com.rsm.yuri.projecttaxilivre.lib.base;

import android.widget.ImageView;

/**
 * Created by yuri_ on 28/12/2017.
 */

public interface ImageLoader {
    void load(ImageView imageView, String URL);
}
