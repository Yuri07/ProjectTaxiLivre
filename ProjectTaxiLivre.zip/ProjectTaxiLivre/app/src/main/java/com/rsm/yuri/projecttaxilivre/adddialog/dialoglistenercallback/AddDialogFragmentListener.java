package com.rsm.yuri.projecttaxilivre.adddialog.dialoglistenercallback;

/**
 * Created by yuri_ on 26/02/2018.
 */

public interface AddDialogFragmentListener {
    public void onFinishAddDialog(String key, String inputText);
}
