package com.rsm.yuri.projecttaxilivre.login;

/**
 * Created by yuri_ on 12/01/2018.
 */

public interface SignupInteractor {

    void execute(String email, String password);

}
