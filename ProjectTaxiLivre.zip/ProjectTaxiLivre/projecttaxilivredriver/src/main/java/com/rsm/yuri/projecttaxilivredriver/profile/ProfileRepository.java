package com.rsm.yuri.projecttaxilivredriver.profile;

import android.net.Uri;

/**
 * Created by yuri_ on 08/03/2018.
 */

public interface ProfileRepository {
    void uploadPhoto(Uri selectedImageUri);
}
