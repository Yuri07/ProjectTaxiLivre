package com.rsm.yuri.projecttaxilivredriver.home.models;

/**
 * Created by yuri_ on 03/02/2018.
 */

public class Area {
    private String id;
    private int aX;
    private int aY;


    public Area() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getaX() {
        return aX;
    }

    public void setaX(int aX) {
        this.aX = aX;
    }

    public int getaY() {
        return aY;
    }

    public void setaY(int aY) {
        this.aY = aY;
    }


}
