package com.rsm.yuri.projecttaxilivre.historictravelsllist;

public interface HistoricTravelsListPresenter {
}
