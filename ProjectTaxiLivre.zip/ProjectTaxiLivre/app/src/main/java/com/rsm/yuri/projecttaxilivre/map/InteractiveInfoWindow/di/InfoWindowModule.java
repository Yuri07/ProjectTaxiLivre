package com.rsm.yuri.projecttaxilivre.map.InteractiveInfoWindow.di;

import dagger.Module;

/**
 * Created by yuri_ on 29/03/2018.
 */
@Module
public class InfoWindowModule {
}
