package com.rsm.yuri.projecttaxilivredriver.historictravel.ui;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.rsm.yuri.projecttaxilivredriver.R;

public class HistoricTravelActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_historic_travel);
    }
}
